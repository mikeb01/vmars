Aeron Cluster
===

Usage
=====

Protocol
=====
Messages are specified using SBE in [aeron-cluster-codecs.xml](https://github.com/real-logic/aeron/blob/master/aeron-cluster/src/main/resources/aeron-cluster-codecs.xml).
